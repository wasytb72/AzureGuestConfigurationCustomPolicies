#!/bin/bash
# 
# This script installs GC on Linux and starts the GC service.
# 

DSC_HOME_PATH="$PWD"
GC_EXE_PATH="$DSC_HOME_PATH/gc_linux_service"
DSC_CLIENT_EXE_PATH="$DSC_HOME_PATH/dsc_client"
DSC_SERVER_SOCKET_PATH="$DSC_HOME_PATH/sockets"
EXT_SERVER_SOCKET_PATH="$DSC_HOME_PATH/ext_sockets"
SERVICE_TEMP_FOLDER_PATH="$DSC_HOME_PATH/service_temp"


SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/gc_service_controller"
SERVICE_CONTROLLER_PATH_EXT="$SERVICE_SCRIPTS_FOLDER_PATH/ext_service_controller"

DSC_SERVICE_NAME="gcd"
EXT_SERVICE_NAME="extd"

DSC_SYSTEMD_FILE_NAME="$DSC_SERVICE_NAME.systemd"
DSC_SYSTEMD_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"
DSC_SYSTEMD_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_SYSTEMD_FILE_NAME"

DSC_UPSTART_FILE_NAME="$DSC_SERVICE_NAME.upstart"
DSC_UPSTART_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"
DSC_UPSTART_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$DSC_UPSTART_FILE_NAME"

EXT_SYSTEMD_FILE_NAME="$EXT_SERVICE_NAME.systemd"
EXT_SYSTEMD_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$EXT_SYSTEMD_FILE_NAME"
EXT_SYSTEMD_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$EXT_SYSTEMD_FILE_NAME"

EXT_UPSTART_FILE_NAME="$EXT_SERVICE_NAME.upstart"
EXT_UPSTART_SOURCE_FILE_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/$EXT_UPSTART_FILE_NAME"
EXT_UPSTART_TEMP_FILE_PATH="$SERVICE_TEMP_FOLDER_PATH/$EXT_UPSTART_FILE_NAME"

SYSTEMD_UNIT_DIR=""
SYSTEM_SERVICE_CONTROLLER=""

LINUX_DISTRO=""

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

compareversion () {
    if [[ $1 == $2 ]]
    then
        return 0
    fi

    local IFS=.
    local i version1=($1) version2=($2)

    # Fill zeros in version1 if its lenth is less than version2
    for ((i=${#version1[@]}; i<${#version2[@]}; i++))
    do
        version1[i]=0
    done

    for ((i=0; i<${#version1[@]}; i++))
    do
        if [[ -z ${version2[i]} ]]
        then
            # Fill zeros in version2 if its lenth is less than version1
            version2[i]=0
        fi

        # compare the version digits
        if ((10#${version1[i]} > 10#${version2[i]}))
        then
            return 1
        fi
        if ((10#${version1[i]} < 10#${version2[i]}))
        then
            return 2
        fi
    done
    return 0
}

get_linux_version() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        LINUX_DISTRO_VERSION=$VERSION_ID
    elif type lsb_release >/dev/null 2>&1; then
        LINUX_DISTRO_VERSION=$(lsb_release -sr)
    elif [ -f /etc/lsb-release ]; then
        . /etc/lsb-release
        LINUX_DISTRO_VERSION=$DISTRIB_RELEASE
    elif [ -f /etc/debian_version ]; then
        LINUX_DISTRO_VERSION=$(cat /etc/debian_version)
    else
        # Fall back to uname.
        LINUX_DISTRO_VERSION=$(uname -r)
    fi

    if [ -z $LINUX_DISTRO_VERSION ]; then
        print_error "Unexpected error occurred while getting the distro version."
        exit 1
    fi
    echo "Linux distribution version is $LINUX_DISTRO_VERSION."
}

get_linux_distro() {
    if [ ! -z $LINUX_DISTRO ]; then
        return
    fi

    get_linux_version

    VERSION_OUTPUT=$(cat /proc/version)

    if [[ $VERSION_OUTPUT = *"Ubuntu"* ]]; then
        LINUX_DISTRO="Ubuntu"
        MIN_SUPPORTED_DISTRO_VERSION="14.04"
    elif [[ $VERSION_OUTPUT = *"Red Hat"* ]]; then
        LINUX_DISTRO="Red Hat"
        MIN_SUPPORTED_DISTRO_VERSION="7.0"
    elif [[ $VERSION_OUTPUT = *"SUSE"* ]]; then
        LINUX_DISTRO="SUSE"
        MIN_SUPPORTED_DISTRO_VERSION="12.0"
    elif [[ $VERSION_OUTPUT = *"CentOS"* ]]; then
        LINUX_DISTRO="CentOS"
        MIN_SUPPORTED_DISTRO_VERSION="7.0"
    elif [[ $VERSION_OUTPUT = *"Debian"* ]]; then
        LINUX_DISTRO="Debian"
        MIN_SUPPORTED_DISTRO_VERSION="8.0"
    else
        print_error "Unexpected Linux distribution. Expected Linux distributions include only Ubuntu, Red Hat, SUSE, CentOS, and Debian."
        # Exit with error code 51 (The extension is not supported on this OS)
        exit 51
    fi

    compareversion $LINUX_DISTRO_VERSION $MIN_SUPPORTED_DISTRO_VERSION
    if [[ $? -eq 2 ]]; then
        print_error "Unsupported $LINUX_DISTRO version $LINUX_DISTRO_VERSION. $LINUX_DISTRO version should be greater or equal than $MIN_SUPPORTED_DISTRO_VERSION."
        # Exit with error code 51 (The extension is not supported on this OS)
        exit 51
    fi

    echo "Linux distribution is $LINUX_DISTRO."
}

get_system_service_controller() {
    if [ ! -z $SYSTEM_SERVICE_CONTROLLER ]; then
        return
    fi

    COMM_OUTPUT=$(cat /proc/1/comm)

    if [[ $COMM_OUTPUT = *"systemd"* ]]; then
        SYSTEM_SERVICE_CONTROLLER="systemd"
    elif [[ $COMM_OUTPUT = *"init"* ]]; then
        SYSTEM_SERVICE_CONTROLLER="upstart"
    else
        print_error "Unexpected system service controller. Expected system service controllers are systemd and upstart."
        exit 1
    fi

    echo "Service controller is $SYSTEM_SERVICE_CONTROLLER."
}

resolve_systemd_paths() {
    local UNIT_DIR_LIST="/usr/lib/systemd/system /lib/systemd/system"

    # Be sure systemctl lives where we expect it to
    if [ ! -f /bin/systemctl ]; then
        print_error "FATAL: Unable to locate systemctl program"
        exit 1
    fi

    # Find systemd unit directory
    for i in ${UNIT_DIR_LIST}; do
        if [ -d $i ]; then
            SYSTEMD_UNIT_DIR=${i}
            return 0
        fi
    done

    # Didn't find unit directory, that's fatal
    print_error "FATAL: Unable to resolve systemd unit directory"
    exit 1
}

create_systemd_config_file() {
    # Remove any old temp systemd configuration file that may exist
    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        if [ -f $EXT_SYSTEMD_TEMP_FILE_PATH ]; then
        sudo rm -f $EXT_SYSTEMD_TEMP_FILE_PATH
        fi
    else
        if [ -f $DSC_SYSTEMD_TEMP_FILE_PATH ]; then
        sudo rm -f $DSC_SYSTEMD_TEMP_FILE_PATH
        fi
    fi
    

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        # Replace the pid file and exe file paths in the systemd configuration file
        cat $EXT_SYSTEMD_SOURCE_FILE_PATH | sed "s@<EXE_FILE_PATH>@$GC_EXE_PATH@g" > $EXT_SYSTEMD_TEMP_FILE_PATH;

        # Set the new temp systemd configuration file to the correct permissions  
        chmod 644 $EXT_SYSTEMD_TEMP_FILE_PATH;
    else
        # Replace the pid file and exe file paths in the systemd configuration file
        cat $DSC_SYSTEMD_SOURCE_FILE_PATH | sed "s@<EXE_FILE_PATH>@$GC_EXE_PATH@g" > $DSC_SYSTEMD_TEMP_FILE_PATH;

        # Set the new temp systemd configuration file to the correct permissions  
        chmod 644 $DSC_SYSTEMD_TEMP_FILE_PATH;
    fi

    
}

install_systemd_service() {
    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        echo "Found systemd service controller...for Extension Service"
        resolve_systemd_paths
        create_systemd_config_file $1
        cp -f $EXT_SYSTEMD_TEMP_FILE_PATH ${SYSTEMD_UNIT_DIR}/extd.service
        chmod 644 ${SYSTEMD_UNIT_DIR}/extd.service
        /bin/systemctl daemon-reload
        /bin/systemctl enable extd 2>&1
        echo "Service configured through systemd service controller. Extension Service"
    else    
        echo "Found systemd service controller...for GC Service"
        resolve_systemd_paths
        create_systemd_config_file $1
        cp -f $DSC_SYSTEMD_TEMP_FILE_PATH ${SYSTEMD_UNIT_DIR}/gcd.service
        chmod 644 ${SYSTEMD_UNIT_DIR}/gcd.service
        /bin/systemctl daemon-reload
        /bin/systemctl enable gcd 2>&1
        echo "Service configured through systemd service controller. Dsc Service"
    fi
}

create_upstart_config_file() {
    # Remove any old temp upstart configuration file that may exist
    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        if [ -f $EXT_UPSTART_TEMP_FILE_PATH ]; then
            sudo rm -f $EXT_UPSTART_TEMP_FILE_PATH
        fi
    else
        if [ -f $DSC_UPSTART_TEMP_FILE_PATH ]; then
            sudo rm -f $DSC_UPSTART_TEMP_FILE_PATH
        fi
    fi
    

    if [ ! -d $SERVICE_TEMP_FOLDER_PATH ]; then
        mkdir $SERVICE_TEMP_FOLDER_PATH
    fi

    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        # Replace the exe file path in the upstart configuration file
        cat $EXT_UPSTART_SOURCE_FILE_PATH | sed "s@<GC_EXE_PATH>@$GC_EXE_PATH@g" > $EXT_UPSTART_TEMP_FILE_PATH;

        # Set the new temp upstart configuration file to the correct permissions  
        chmod 644 $EXT_UPSTART_TEMP_FILE_PATH;
    else
        # Replace the exe file path in the upstart configuration file
        cat $DSC_UPSTART_SOURCE_FILE_PATH | sed "s@<GC_EXE_PATH>@$GC_EXE_PATH@g" > $DSC_UPSTART_TEMP_FILE_PATH;

        # Set the new temp upstart configuration file to the correct permissions  
        chmod 644 $DSC_UPSTART_TEMP_FILE_PATH;
    fi
    
}

install_upstart_service() {
    if [ -x /sbin/initctl -a -f /etc/init/networking.conf ]; then
        # If we have /sbin/initctl, we have upstart.
        # Note that the upstart script requires networking,
        # so only use upstart if networking is controlled by upstart (not the case in RedHat 6)
        echo "Found upstart service controller with networking..."
        create_upstart_config_file $1
        if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
            cp -f $EXT_UPSTART_TEMP_FILE_PATH /etc/init/extd.conf
            chmod 644 /etc/init/extd.conf
        else
            cp -f $DSC_UPSTART_TEMP_FILE_PATH /etc/init/gcd.conf
            chmod 644 /etc/init/gcd.conf
        fi
        
        # initctl registers it with upstart
        initctl reload-configuration
        echo "Service configured through upstart service controller."
    else
        print_error "Upstart service controller does not have control of the networking service."
        exit 1
    fi
}

install_dsc_service() {

    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        # Set the EXT service controller to be executable
        chown root $SERVICE_CONTROLLER_PATH_EXT
        chmod 700 $SERVICE_CONTROLLER_PATH_EXT
    
        $SERVICE_CONTROLLER_PATH_EXT stop
        echo "Configuring EXT service ..."
    else
        # Set the GC service controller to be executable
        chown root $SERVICE_CONTROLLER_PATH
        chmod 700 $SERVICE_CONTROLLER_PATH
    
        $SERVICE_CONTROLLER_PATH stop
        echo "Configuring GC service ..."
    fi
    
    pidof systemd 1> /dev/null 2> /dev/null
    if [ $? -eq 0 ]; then
        install_systemd_service $1
    else
        get_system_service_controller
        case "$SYSTEM_SERVICE_CONTROLLER" in
        "systemd")
            install_systemd_service $1
            ;;
        "upstart")
            install_upstart_service $1
            ;;
        *) echo "Unrecognized system service controller to configure GC service."
            exit 1
            ;;
        esac
    fi
}

install_dsc() {
    chown root $GC_EXE_PATH
    check_result $? "Setting owner of gc_linux_service file failed"

    chown root $DSC_CLIENT_EXE_PATH
    check_result $? "Setting owner of dsc_client file failed"

    chmod 700 $GC_EXE_PATH
    check_result $? "Setting permissions of gc_linux_service file failed"

    chmod 700 $DSC_CLIENT_EXE_PATH
    check_result $? "Setting permissions of dsc_client file failed"

    chown root $DSC_HOME_PATH/*.sh
    check_result $? "Setting owner of .sh files failed"

    chmod 700 $DSC_HOME_PATH/*.sh
    check_result $? "Setting permissions of .sh files failed"

    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        cat <<EOF > "$DSC_HOME_PATH/dsc.config"
        {"ServiceType" : "Extension"}
EOF
        mkdir -p $EXT_SERVER_SOCKET_PATH
        check_result $? "Creating extension sockets directory failed"
        chmod 700 $EXT_SERVER_SOCKET_PATH
        check_result $? "Setting permissions of extension sockets directory failed"
        chown root $EXT_SERVER_SOCKET_PATH
        check_result $? "Changing ownership of extension sockets directory failed"
    else
        mkdir -p $DSC_SERVER_SOCKET_PATH
        check_result $? "Creating sockets directory failed"
        chmod 700 $DSC_SERVER_SOCKET_PATH
        check_result $? "Setting permissions of sockets directory failed"
        chown root $DSC_SERVER_SOCKET_PATH
        check_result $? "Changing ownership of sockets directory failed"
    fi

    install_dsc_service $1
}

install_curl_dependency() {
    get_linux_distro

    case "$LINUX_DISTRO" in

    "Ubuntu")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    "Red Hat")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "SUSE")
        echo "Checking for package 'curl'..."
        if zypper search curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            zypper -n install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "CentOS")
        echo "Checking for package 'curl'..."
        if yum list installed curl >/dev/null 2>&1; then
            echo "Package 'curl' is already installed."
        else
            echo "Installing package 'curl'..."
            yum -y install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        fi
        ;;
    "Debian")
        echo "Checking for package 'curl'..."
        if [ $(dpkg-query -W -f='${Status}' curl 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
            echo "Installing package 'curl'..."
            export DEBIAN_FRONTEND=noninteractive
            apt -yq install curl >/dev/null 2>&1
            check_result $? "Installation of package 'curl' failed."
            echo "Installation of package 'curl' succeeded."
        else
            echo "Package 'curl' is already installed."
        fi
        ;;
    *) echo "Could not install curl dependency packages for unexpected Linux distribution '$LINUX_DISTRO'."
        exit 1 
        ;;
    esac
}

create_guest_config_folder() {
    if [ $# -ne 0 ] && [ $1 = "Extension" ]; then
        return
    fi

    mkdir -p "/var/lib/GuestConfig"
    chmod 700 "/var/lib/GuestConfig"
}

install_curl_dependency
check_result $? "Installation of curl failed"
create_guest_config_folder $1
check_result $? "Failed to create guest config data directory"
install_dsc $1
check_result $? "Installation of GC service failed"
