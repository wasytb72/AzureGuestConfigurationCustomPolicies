This folder should only contain this place holder text file.
